package Enrolment;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Student implements Serializable{

	private static final long serialVersionUID = 1L;
	public String studentId, name, department;
    protected ArrayList<String> completedCoursesList;
 
    public Student(String inputString) throws Exception {
        try{
            StringTokenizer stringTokenizer = new StringTokenizer(inputString);
            this.studentId = stringTokenizer.nextToken();
            this.name = stringTokenizer.nextToken() + " " + stringTokenizer.nextToken();;
            this.department = stringTokenizer.nextToken();
            this.completedCoursesList = new ArrayList<>();
            while (stringTokenizer.hasMoreTokens()) this.completedCoursesList.add(stringTokenizer.nextToken());
        }catch (Exception e){throw new Exception("Wrong Input");}
    }

    public String toString() {
        String stringReturn = this.studentId + " " + this.name + " " + this.department;
        for (String s : this.completedCoursesList) stringReturn = stringReturn + " " + s;
        return stringReturn;
    }
}
