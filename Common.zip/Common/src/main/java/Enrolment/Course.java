package Enrolment;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Course implements Serializable{

	private static final long serialVersionUID = 1L;
	protected String courseId, professor, name;
    protected ArrayList<String> needCoursesList;

    public Course(String inputString) throws Exception {
        try {
            StringTokenizer stringTokenizer = new StringTokenizer(inputString);
            this.courseId = stringTokenizer.nextToken();
            this.professor = stringTokenizer.nextToken();
            this.name = stringTokenizer.nextToken();
            this.needCoursesList = new ArrayList<>();
            while (stringTokenizer.hasMoreTokens()) this.needCoursesList.add(stringTokenizer.nextToken());
        } catch (Exception e) {throw new Exception("Wrong Input");}
    }

    public String toString() {
        String stringReturn = this.courseId + " " + this.professor + " " + this.name;
        for (String s : this.needCoursesList) stringReturn = stringReturn + " " + s;
        return stringReturn;
    }
}
