package Enrolment;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class StudentList {

	protected ArrayList<Student> vStudent;

	public StudentList(String sStudentFileName) throws Exception {
		BufferedReader objStudentFile = new BufferedReader(new FileReader(sStudentFileName));
		this.vStudent = new ArrayList<>();
		while (objStudentFile.ready()) {
			String stuInfo = objStudentFile.readLine();
			if (!stuInfo.equals("")) this.vStudent.add(new Student(stuInfo));
		}
		objStudentFile.close();
	}

	public void enrolment(String studentId, Course course) throws Exception {
		Student student = this.find(studentId);
		if(student.completedCoursesList.contains(course.courseId)) throw new Exception("Already Enrolment Course");
		for(String courseId : course.needCoursesList){
			if (!student.completedCoursesList.contains(courseId)) throw new Exception("Not Completed Preceding Courses");
		}
		student.completedCoursesList.add(course.courseId);
	}

	public void addStudent(Student student) {this.vStudent.add(student);}
	public void deleteStudent(String id) throws Exception {
		Student target = this.find(id);
		if(target != null) vStudent.remove(target);
	}
	public Student find(String id) throws Exception {
		for(Student student : vStudent){
			if(student.studentId.equals(id)) return student;
		}
		throw new Exception("No Student");
	}
	public String getFileContent(){
		String result = "";
		for (Student student : this.vStudent) result+=student.toString()+"\r\n";
		return result;
	}
	public boolean isNoData(){return this.vStudent.size()==0;}
}
