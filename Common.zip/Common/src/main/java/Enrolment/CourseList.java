package Enrolment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CourseList {

	protected ArrayList<Course> vCourses;

	public CourseList(String sCourseFileName) throws Exception {
		BufferedReader objCourseFile = new BufferedReader(new FileReader(sCourseFileName));
		this.vCourses = new ArrayList<>();
		while (objCourseFile.ready()) {
			String courseInfo = objCourseFile.readLine();
			if (!courseInfo.equals("")) this.vCourses.add(new Course(courseInfo));
		}
		objCourseFile.close();
	}

	public void addCourse(Course course) { this.vCourses.add(course); }
	public void deleteCourse(String id) throws Exception {
		Course target = this.find(id);
		if(target != null) vCourses.remove(target);
	}
	public Course find(String id) throws Exception{
		for(Course course : vCourses){
			if(course.courseId.equals(id)) return course;
		}
		throw new Exception("No Course");
	}
	public String getFileContent(){
		String result = "";
		for (Course course : this.vCourses) result+=course.toString()+"\r\n";
		return result;
	}
	public boolean isNoData(){return this.vCourses.size()==0;}
}
