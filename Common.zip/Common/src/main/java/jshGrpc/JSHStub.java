package jshGrpc;

import com.demo.grpc.JsonRequest;
import com.demo.grpc.JsonResponse;
import com.demo.grpc.JsonServiceGrpc;
import com.google.gson.Gson;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class JSHStub {

    private final JsonServiceGrpc.JsonServiceBlockingStub stub;

    public JSHStub(String name, int portNumber){
        ManagedChannel channel = ManagedChannelBuilder.forAddress(name, portNumber).usePlaintext().build();
        this.stub = JsonServiceGrpc.newBlockingStub(channel);
    }

    public Object request(Object parameter) throws Exception {
        String method = Thread.currentThread().getStackTrace()[2].getMethodName();
        Gson gson = new Gson();
        JSHRequest jshRequest = new JSHRequest(method, parameter);
        JsonRequest jsonRequest = JsonRequest.newBuilder().setJson(gson.toJson(jshRequest)).build();
        JsonResponse jsonResponse = this.stub.request(jsonRequest);
        JSHResponse jshResponse = gson.fromJson(jsonResponse.getJson(), JSHResponse.class);
        if(jshResponse.error) throw new Exception(jshResponse.errorMessage);
        else if(jshResponse.result ==null) return null;
        else return gson.fromJson(jshResponse.result, Class.forName(jshResponse.type));
    }
}
