package jshGrpc;

import com.google.gson.Gson;

public class JSHRequest {

    public String method, type, parameter;

    public JSHRequest(String method, Object parameter) {
        this.method=method;
        if (parameter != null) {
            this.type = parameter.getClass().getName();
            this.parameter = new Gson().toJson(parameter);
        }
    }
}
