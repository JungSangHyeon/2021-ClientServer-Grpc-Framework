package jshGrpc;

import com.google.gson.Gson;

public class JSHResponse {

    public String errorMessage, type, result;
    public boolean error;

    public JSHResponse(Object result) {
        this.error = false;
        if (result != null) {
            this.type = result.getClass().getName();
            this.result = new Gson().toJson(result);
        }
    }
    public JSHResponse(String errorMessage) {
        this.error = true;
        this.errorMessage = errorMessage;
    }
}
