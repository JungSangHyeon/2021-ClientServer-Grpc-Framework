package jshGrpc;

import com.demo.grpc.JsonRequest;
import com.demo.grpc.JsonResponse;
import com.demo.grpc.JsonServiceGrpc;
import com.google.gson.Gson;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import java.io.IOException;
import java.lang.reflect.Method;

public class JSHSkeleton extends JsonServiceGrpc.JsonServiceImplBase {

    private int index = 1;

    public void start(int portNumber) {
        try {
            Server server = ServerBuilder.forPort(portNumber).addService(this).build();
            System.out.println("Server Start. Port : "+portNumber);
            server.start();
            server.awaitTermination();
        } catch (InterruptedException | IOException e) {e.printStackTrace();}
    }

    @Override
    public void request(JsonRequest request, StreamObserver<JsonResponse> responseObserver) {
        Gson gson = new Gson();
        JSHRequest jshRequest = gson.fromJson(request.getJson(), JSHRequest.class);
        System.out.println("( " + index++ + " )");
        System.out.println("Get Request: " + jshRequest.method);
        JSHResponse jshResponse = this.processRequest(jshRequest);
        JsonResponse jsonResponse = JsonResponse.newBuilder().setJson(gson.toJson(jshResponse)).build();
        responseObserver.onNext(jsonResponse);
        responseObserver.onCompleted();
        System.out.println("----------------------");
    }
    private JSHResponse processRequest(JSHRequest jshRequest) {
        try{
            Object returnObject;
            if(jshRequest.parameter !=null) returnObject = processOneParameterRequest(jshRequest);
            else returnObject = processZeroParameterRequest(jshRequest);
            System.out.println("Return Result");
            return new JSHResponse(returnObject);
        }catch(Exception e){
            System.out.println("Return Error : " + e.getCause().getMessage());
            return new JSHResponse(e.getCause().getMessage());
        }
    }
    private Object processOneParameterRequest(JSHRequest jshRequest) throws Exception {
        Class<?> cls = Class.forName(jshRequest.type);
        Method method = this.getClass().getMethod(jshRequest.method, cls);
        return method.invoke(this, new Gson().fromJson(jshRequest.parameter, cls));
    }
    private Object processZeroParameterRequest(JSHRequest jshRequest) throws Exception{
        Method method = this.getClass().getMethod(jshRequest.method);
        return method.invoke(this);
    }
}
