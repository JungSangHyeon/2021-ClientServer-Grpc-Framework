package jshMenu;

import java.lang.reflect.Method;
import java.util.*;

/**
 *  Rule: public <Return Type> <prefix><index><Delimiter><Method Name>
 *  Ex) public void method3_hello
 */
public class JSHTUIMenu {

    private static final String PREFIX = "method", DELIMITER = "_", EXIT = "exit";
    private final Map<Integer, Method> methodMap;
    private final int[] indexes;
    protected Scanner sc;
    private boolean exit = false;

    public JSHTUIMenu(){
        this.sc = new Scanner(System.in);
        this.methodMap = new HashMap<>();
        for(Method method : this.getClass().getMethods()){
            if(method.getName().startsWith(PREFIX)) this.methodMap.put(this.getIndex(method), method);
        }
        this.indexes = this.methodMap.keySet().stream().mapToInt(i -> i).toArray();
        Arrays.sort(this.indexes);
    }

    public void start(){ while(!this.exit) this.call(); }
    protected void call(){
        System.out.println("-------------------- Menu --------------------");
        for(int index : this.indexes) System.out.println(index+". "+this.getName(this.methodMap.get(index)));
        System.out.println(EXIT+". 종료");

        String line = this.sc.nextLine();
        if(line.equals(EXIT)){ this.exit = true; System.out.println("종료합니다.");}
        else this.invoke(line);
    }
    private void invoke(String line) {
        try {
            Method method = this.methodMap.get(Integer.parseInt(line));
            method.invoke(this);
            System.out.println(this.getName(method)+" Finished");
        } catch (NumberFormatException | NullPointerException e) { System.err.println("올바른 값을 입력해주세요."); }
        catch (Exception e) { System.err.println(e.getCause().getMessage()); }
    }

    private int getIndex(Method method){ return Integer.parseInt(this.split(method)[0]); }
    private String getName(Method method){ return this.split(method)[1]; }
    private String[] split(Method method){return method.getName().substring(PREFIX.length()).split(DELIMITER);}
}
